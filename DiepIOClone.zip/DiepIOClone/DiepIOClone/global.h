#pragma once
extern long ticks;
