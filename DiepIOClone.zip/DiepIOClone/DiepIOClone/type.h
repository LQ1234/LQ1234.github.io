#pragma once
#include <SFML/Graphics.hpp>

class player;//let the compiler know  that player EXISTS
#include <vector>
class bullet;//let the compiler know  that bullet EXISTS

class type {
public:
	type(sf::Sprite* spri, std::vector<bullet*> (*shootF)(player* thisPlayer),int rlt);
	sf::Sprite* thissprite;

	std::vector<bullet*> (*shootFunc)(player* thisPlayer);
	int reloadTime;
};