// SFMLTEST.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include "pch.h"
#include "global.h"

#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
#include "ai.h"
#include "type.h"

#include "player.h"
#include "bullet.h"
#include <chrono>
#include <thread>
#include <random>
long ticks;
double dist(double x1, double y1, double x2, double y2) {
	return(sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2)));
}
sf::Sprite*  spriteFuncDefault() {
	sf::RenderTexture* texture=new sf::RenderTexture();
	texture->create(200, 100);
	texture->clear(sf::Color::Transparent);

	sf::RectangleShape rectangle(sf::Vector2f(63, 34));
	rectangle.setPosition(50, 50 - 17);
	rectangle.setFillColor(sf::Color(175, 175, 175));
	texture->draw(rectangle);

	sf::RectangleShape rectangleI(sf::Vector2f(59, 26));
	rectangleI.setPosition(50, 50 - 13);
	rectangleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(rectangleI);

	sf::CircleShape circle;
	circle.setRadius(31);
	circle.setPosition(50 - 31, 50 - 31);
	circle.setFillColor(sf::Color(150, 150, 150));
	texture->draw(circle);

	sf::CircleShape circleI;
	circleI.setRadius(26);
	circleI.setPosition(50 - 26, 50 - 26);
	circleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(circleI);
	texture->setSmooth(false);
	sf::Sprite* sprite=new sf::Sprite();
	sprite->setTexture(texture->getTexture());
	sprite->setOrigin(sf::Vector2f(50.f, 50.f));
	return(sprite);
}
std::vector<bullet*> shootFuncDefaut(player* thisPlayer){
	std::vector<bullet*> bullets;
	bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle) * 60, (*thisPlayer).y + sin((*thisPlayer).aimAngle) * 60, cos((*thisPlayer).aimAngle) * 15 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle) * 15 + (*thisPlayer).yv,18,8, thisPlayer));
	return(bullets);
}
sf::Sprite*  spriteFuncTwin() {
	sf::RenderTexture* texture = new sf::RenderTexture();
	texture->create(200, 100);
	texture->clear(sf::Color::Transparent);

	sf::RectangleShape rectangleA(sf::Vector2f(63, 34-10));
	rectangleA.setPosition(50, 50 - 12+13);
	rectangleA.setFillColor(sf::Color(175, 175, 175));
	texture->draw(rectangleA);

	sf::RectangleShape rectangleIA(sf::Vector2f(59, 26-10));
	rectangleIA.setPosition(50, 50 - 13 +5+13);
	rectangleIA.setFillColor(sf::Color(210, 210, 210));
	texture->draw(rectangleIA);

	sf::RectangleShape rectangleB(sf::Vector2f(63, 34-10));
	rectangleB.setPosition(50, 50 - 17+5-13);
	rectangleB.setFillColor(sf::Color(175, 175, 175));
	texture->draw(rectangleB);

	sf::RectangleShape rectangleIB(sf::Vector2f(59, 26-10));
	rectangleIB.setPosition(50, 50 - 13 + 5-13);
	rectangleIB.setFillColor(sf::Color(210, 210, 210));
	texture->draw(rectangleIB);

	sf::CircleShape circle;
	circle.setRadius(31);
	circle.setPosition(50 - 31, 50 - 31);
	circle.setFillColor(sf::Color(150, 150, 150));
	texture->draw(circle);

	sf::CircleShape circleI;
	circleI.setRadius(26);
	circleI.setPosition(50 - 26, 50 - 26);
	circleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(circleI);
	texture->setSmooth(false);
	sf::Sprite* sprite = new sf::Sprite();
	sprite->setTexture(texture->getTexture());
	sprite->setOrigin(sf::Vector2f(50.f, 50.f));
	return(sprite);
}
std::vector<bullet*> shootFuncTwin(player* thisPlayer) {
	std::vector<bullet*> bullets;
	bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle+.25) * 60, (*thisPlayer).y + sin((*thisPlayer).aimAngle+.25) * 60, cos((*thisPlayer).aimAngle) * 15 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle) * 15 + (*thisPlayer).yv,11,5, thisPlayer));
	bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle-.25) * 60, (*thisPlayer).y + sin((*thisPlayer).aimAngle-.25) * 60, cos((*thisPlayer).aimAngle) * 15 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle) * 15 + (*thisPlayer).yv, 11,5, thisPlayer));

	return(bullets);
}
sf::Sprite*  spriteFuncSnipe() {
	sf::RenderTexture* texture = new sf::RenderTexture();
	texture->create(200, 100);
	texture->clear(sf::Color::Transparent);

	sf::RectangleShape rectangle(sf::Vector2f(63+15, 34));
	rectangle.setPosition(50, 50 - 17);
	rectangle.setFillColor(sf::Color(175, 175, 175));
	texture->draw(rectangle);

	sf::RectangleShape rectangleI(sf::Vector2f(59+15, 26));
	rectangleI.setPosition(50, 50 - 13);
	rectangleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(rectangleI);

	sf::CircleShape circle;
	circle.setRadius(31);
	circle.setPosition(50 - 31, 50 - 31);
	circle.setFillColor(sf::Color(150, 150, 150));
	texture->draw(circle);

	sf::CircleShape circleI;
	circleI.setRadius(26);
	circleI.setPosition(50 - 26, 50 - 26);
	circleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(circleI);
	texture->setSmooth(false);
	sf::Sprite* sprite = new sf::Sprite();
	sprite->setTexture(texture->getTexture());
	sprite->setOrigin(sf::Vector2f(50.f, 50.f));
	return(sprite);
}
std::vector<bullet*> shootFuncSnipe(player* thisPlayer) {
	std::vector<bullet*> bullets;
	bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle) * 60, (*thisPlayer).y + sin((*thisPlayer).aimAngle) * 60, cos((*thisPlayer).aimAngle) * 30 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle) * 30 + (*thisPlayer).yv, 18, 30, thisPlayer));

	return(bullets);
}
sf::Sprite*  spriteFuncShotgun() {
	sf::RenderTexture* texture = new sf::RenderTexture();
	texture->create(200, 100);
	texture->clear(sf::Color::Transparent);



	sf::ConvexShape turrO;
	turrO.setFillColor(sf::Color(175, 175, 175));
	turrO.setPointCount(4);
	turrO.setPoint(0, sf::Vector2f(60, 35));
	turrO.setPoint(1, sf::Vector2f(60, 65));
	turrO.setPoint(2, sf::Vector2f(121, 70));
	turrO.setPoint(3, sf::Vector2f(121, 30));
	texture->draw(turrO);

	sf::ConvexShape turrA;
	turrA.setFillColor(sf::Color(210, 210, 210));
	turrA.setPointCount(4);
	turrA.setPoint(0, sf::Vector2f(60, 39));
	turrA.setPoint(1, sf::Vector2f(60, 61));
	turrA.setPoint(2, sf::Vector2f(116, 65));
	turrA.setPoint(3, sf::Vector2f(116, 35));
	texture->draw(turrA);



	/*

	sf::RectangleShape rectangle(sf::Vector2f(63 + 15, 34));
	rectangle.setPosition(50, 50 - 17);
	rectangle.setFillColor(sf::Color(175, 175, 175));
	texture->draw(rectangle);

	sf::RectangleShape rectangleI(sf::Vector2f(59 + 15, 26));
	rectangleI.setPosition(50, 50 - 13);
	rectangleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(rectangleI);*/

	sf::CircleShape circle;
	circle.setRadius(31);
	circle.setPosition(50 - 31, 50 - 31);
	circle.setFillColor(sf::Color(150, 150, 150));
	texture->draw(circle);

	sf::CircleShape circleI;
	circleI.setRadius(26);
	circleI.setPosition(50 - 26, 50 - 26);
	circleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(circleI);
	texture->setSmooth(false);
	sf::Sprite* sprite = new sf::Sprite();
	sprite->setTexture(texture->getTexture());
	sprite->setOrigin(sf::Vector2f(50.f, 50.f));
	return(sprite);
}
std::random_device rd;

std::vector<bullet*> shootFuncShotgun(player* thisPlayer) {
	std::vector<bullet*> bullets;
	for (float i = -.2; i <= .2; i += (rd()%5+1)/25.0) {
		bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle + i/2) * 60, (*thisPlayer).y + sin((*thisPlayer).aimAngle + i/2) * 60, cos((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).yv, 10, 4, thisPlayer));
	}
	for (float i = -.2; i <= .2; i += (rd() % 5 + 1) / 25.0) {
		bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle + i / 2) * 50, (*thisPlayer).y + sin((*thisPlayer).aimAngle + i / 2) * 50, cos((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).yv, 10, 4, thisPlayer));
	}
	return(bullets);
}

sf::Sprite*  spriteFuncMaster(){
	sf::RenderTexture* texture = new sf::RenderTexture();
	texture->create(200, 100);
	texture->clear(sf::Color::Transparent);



	sf::ConvexShape turrO;
	turrO.setFillColor(sf::Color(175, 175, 175));
	turrO.setPointCount(4);
	turrO.setPoint(0, sf::Vector2f(60, 35));
	turrO.setPoint(1, sf::Vector2f(60, 65));
	turrO.setPoint(2, sf::Vector2f(121-8, 90));
	turrO.setPoint(3, sf::Vector2f(121-8, 10));
	texture->draw(turrO);

	sf::ConvexShape turrA;
	turrA.setFillColor(sf::Color(210, 210, 210));
	turrA.setPointCount(4);
	turrA.setPoint(0, sf::Vector2f(60, 39+2));
	turrA.setPoint(1, sf::Vector2f(60, 61-2));
	turrA.setPoint(2, sf::Vector2f(116-8, 85-2));
	turrA.setPoint(3, sf::Vector2f(116-8, 15+2));
	texture->draw(turrA);



	

	sf::RectangleShape rectangle(sf::Vector2f(76, 76));
	rectangle.setPosition(50-38, 50 -38);
	rectangle.setFillColor(sf::Color(150, 150, 150));
	texture->draw(rectangle);

	sf::RectangleShape rectangleI(sf::Vector2f(68,68));
	rectangleI.setPosition(50-34, 50-34);
	rectangleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(rectangleI);

	texture->setSmooth(false);
	sf::Sprite* sprite = new sf::Sprite();
	sprite->setTexture(texture->getTexture());
	sprite->setOrigin(sf::Vector2f(50.f, 50.f));
	sprite->setScale(.8, .8);

	return(sprite);
}

std::vector<bullet*> shootFuncMaster(player* thisPlayer) {
	std::vector<bullet*> bullets;/*
	for (float i = -.2; i <= .2; i += (rd() % 5 + 1) / 25.0) {
		bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle + i / 2) * 60, (*thisPlayer).y + sin((*thisPlayer).aimAngle + i / 2) * 60, cos((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).yv, 10, 4, thisPlayer));
	}
	for (float i = -.2; i <= .2; i += (rd() % 5 + 1) / 25.0) {
		bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle + i / 2) * 50, (*thisPlayer).y + sin((*thisPlayer).aimAngle + i / 2) * 50, cos((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle + i) * 20 + (*thisPlayer).yv, 10, 4, thisPlayer));
	}*/
	return(bullets);
}

sf::Sprite*  spriteFuncSlave() {
	sf::RenderTexture* texture = new sf::RenderTexture();
	texture->create(200, 100);
	texture->clear(sf::Color::Transparent);

	sf::RectangleShape rectangle(sf::Vector2f(63, 34));
	rectangle.setPosition(50, 50 - 17);
	rectangle.setFillColor(sf::Color(175, 175, 175));
	texture->draw(rectangle);

	sf::RectangleShape rectangleI(sf::Vector2f(59, 26));
	rectangleI.setPosition(50, 50 - 13);
	rectangleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(rectangleI);

	sf::CircleShape circle;
	circle.setRadius(31);
	circle.setPosition(50 - 31, 50 - 31);
	circle.setFillColor(sf::Color(150, 150, 150));
	texture->draw(circle);

	sf::CircleShape circleI;
	circleI.setRadius(26);
	circleI.setPosition(50 - 26, 50 - 26);
	circleI.setFillColor(sf::Color(210, 210, 210));
	texture->draw(circleI);
	texture->setSmooth(false);
	sf::Sprite* sprite = new sf::Sprite();
	sprite->setTexture(texture->getTexture());
	sprite->setOrigin(sf::Vector2f(50.f, 50.f));
	sprite->setScale(.7,.7);
	return(sprite);
}
std::vector<bullet*> shootFuncSlave(player* thisPlayer) {
	std::vector<bullet*> bullets;
	bullets.push_back(new bullet((*thisPlayer).x + cos((*thisPlayer).aimAngle) * 60, (*thisPlayer).y + sin((*thisPlayer).aimAngle) * 60, cos((*thisPlayer).aimAngle) * 15 + (*thisPlayer).xv, sin((*thisPlayer).aimAngle) * 15 + (*thisPlayer).yv, 18*.7, 8*.7, thisPlayer->owner));
	return(bullets);
}
int WinMain()
{

	type defauttype(spriteFuncDefault(),shootFuncDefaut,7);
	type twintype(spriteFuncTwin(), shootFuncTwin,3);
	type snipetype(spriteFuncSnipe(), shootFuncSnipe, 20);
	type shotguntype(spriteFuncShotgun(), shootFuncShotgun, 10);
	type mastertype(spriteFuncMaster(), shootFuncMaster, 10);
	type slavetype(spriteFuncSlave(), shootFuncSlave, 3);

	ticks = 0;
	sf::Vector2f screensize(800, 700);
	sf::Vector2f halfscreen(screensize.x / 2, screensize.y / 2);

	sf::RenderWindow window(sf::VideoMode(screensize.x, screensize.y), "Diep.io Clone");

	sf::Event event;



	player mainPlayer(&mastertype);
	std::vector<bullet*> bullets;
	std::vector<player*> players;
	std::vector<ai*> ais;

	players.push_back(&mainPlayer);
	sf::Font arial;
	arial.loadFromFile("font/ArialCE.ttf");
	sf::View camera(halfscreen, screensize);
	int gameState = 0;
	bool menuMouseDown = false;
	float arenaSize = 10000;
	float leftbound = -arenaSize/2, rightbound = arenaSize/2, topbound = -arenaSize/2, bottombound = arenaSize/2;
	int kills = 0;
	int menuSelected = 0;
	for (int i = 0; i < 50; i++) {
		player* newai=NULL;
		switch (rd()%4) {
		case 0:
			newai = new player(&defauttype);

			break;
		case 1:
			newai = new player(&twintype);

			break;
		case 2:
			newai = new player(&snipetype);

			break;
		case 3:
			newai = new player(&shotguntype);

			break;
		}

		(*newai).x = rd() % (int)(rightbound - leftbound) + leftbound;
		(*newai).y = rd() % (int)(bottombound - topbound) + topbound;

		players.push_back(newai);
		ai* aiai= new ai(newai);
		ais.push_back(aiai);
		
	}


	while (window.isOpen()) {
		screensize.x=window.getSize().x;
		screensize.y = window.getSize().y;

		halfscreen.x = screensize.x / 2;
		halfscreen.y = screensize.y / 2;
		camera.setSize(screensize);

		if (gameState==0) {
			camera.setCenter(halfscreen);
			window.setView(camera);

			while (window.pollEvent(event)) {

				if (event.type == sf::Event::Closed) {

					window.close();

				}
	
				if (event.type == sf::Event::MouseButtonPressed) {
					if (event.mouseButton.button == sf::Mouse::Left) {
						menuMouseDown = true;
					}
				}
				if (event.type == sf::Event::MouseButtonReleased) {
					if (event.mouseButton.button == sf::Mouse::Left) {
						menuMouseDown = false;
					}
				}
			}

			window.clear(sf::Color(240, 240, 240));

			sf::Text TitleText;
			TitleText.setFont(arial);
			TitleText.setString(std::string("Diep.io Clone"));
			TitleText.setCharacterSize(90);
			sf::FloatRect bounds = TitleText.getLocalBounds();
			TitleText.setFillColor(sf::Color(145, 145, 145));
			TitleText.setPosition( halfscreen.x- bounds.width/2, halfscreen.y -300+20);
			window.draw(TitleText);

			sf::Text subtext;
			subtext.setFont(arial);
			subtext.setString(std::string("Made in c++!"));
			subtext.setCharacterSize(25);
			subtext.setFillColor(sf::Color(103, 186, 219));
			subtext.setPosition(halfscreen.x - bounds.width / 2+5, halfscreen.y - 195 + 20);
			window.draw(subtext);

			sf::Text playerselect;
			playerselect.setFont(arial);
			playerselect.setString(std::string("Select Tank:"));
			playerselect.setCharacterSize(26);
			playerselect.setFillColor(sf::Color(145, 145, 145));
			playerselect.setPosition(halfscreen.x - bounds.width / 2 + 5, halfscreen.y - 185 + 60);
			window.draw(playerselect);

			double min = halfscreen.x - bounds.width / 2, max = halfscreen.x + bounds.width / 2, width = (max - min - 3 * 15) / 4;
			sf::Vector2i mousePos = sf::Mouse::getPosition(window);
			
			for (int i = 0; i < 4;i++) {
				sf::RectangleShape rect(sf::Vector2f(width, width));
				rect.setPosition(sf::Vector2f(min+(width+15)*i+6, halfscreen.y -75 ));

				rect.setFillColor(sf::Color(180, 180, 180));
				
				window.draw(rect);
				sf::RectangleShape rectI(sf::Vector2f(width-10, width-10));
				rectI.setPosition(sf::Vector2f(min + (width + 15)*i + 6+5, halfscreen.y - 75+5));
				rectI.setFillColor(sf::Color(240, 240, 240));
				window.draw(rectI);

				sf::Sprite*  tankDgram = NULL;
				switch (i) {
				case 0:
					tankDgram = mastertype.thissprite;
					break;
				case 1:
					tankDgram = twintype.thissprite;
					break;
				case 2:
					tankDgram = snipetype.thissprite;
					break;
				case 3:
					tankDgram = shotguntype.thissprite;
					break;
				}
				tankDgram->setRotation(-45);
				tankDgram->setPosition(min + (width + 15)*i + 6+width*.4, halfscreen.y - 75 + 5+width*.6);
				window.draw(*tankDgram);
				if (min + (width + 15)*i + 6 < mousePos.x&&mousePos.x < min + (width + 15)*i + 6 + width &&
					halfscreen.y - 75 < mousePos.y&&mousePos.y < halfscreen.y - 75 + width) {
					sf::RectangleShape rectOvr(sf::Vector2f(width , width));
					rectOvr.setPosition(sf::Vector2f(min + (width + 15)*i + 6, halfscreen.y - 75));
					rectOvr.setFillColor(sf::Color(160, 160, 160,70));
					window.draw(rectOvr);
					if (menuMouseDown)menuSelected = i;
				}
				if (menuSelected == i) {
					sf::RectangleShape rectOvr2(sf::Vector2f(width, width));
					rectOvr2.setPosition(sf::Vector2f(min + (width + 15)*i + 6, halfscreen.y - 75));
					rectOvr2.setFillColor(sf::Color(103, 186, 219, 100));
					window.draw(rectOvr2);
				}
				sf::Text tankname;
				tankname.setFont(arial);
				switch (i) {
				case 0:

					tankname.setString(std::string("Master"));
					break;
				case 1:
					tankname.setString(std::string("Twin"));
					break;
				case 2:
					tankname.setString(std::string("Sniper"));
					break;
				case 3:
					tankname.setString(std::string("Shotgun"));
					break;
				}
				tankname.setCharacterSize(25);
				sf::FloatRect bounds = tankname.getLocalBounds();
				tankname.setFillColor(sf::Color(145, 145, 145));
				tankname.setPosition(min + (width + 15)*i + 6 +width/2- bounds.width / 2, halfscreen.y +50);
				window.draw(tankname);

			}

			sf::RectangleShape playbtnO(sf::Vector2f(190,80));
			playbtnO.setPosition(sf::Vector2f(-190 /2+halfscreen.x, halfscreen.y + 120));
			playbtnO.setFillColor(sf::Color(145, 145, 145));
			window.draw(playbtnO);

			sf::RectangleShape playbtnI(sf::Vector2f(190-14, 80-14));
			playbtnI.setPosition(sf::Vector2f(-190 / 2 + halfscreen.x+7, halfscreen.y + 120+7));
			playbtnI.setFillColor(sf::Color(220, 220, 220));
			window.draw(playbtnI);

			sf::Text playtext;
			playtext.setFont(arial);
			playtext.setString(std::string("Start"));
			playtext.setCharacterSize(45);
			playtext.setFillColor(sf::Color(145, 145, 145));
			bounds = playtext.getLocalBounds();

			playtext.setPosition(halfscreen.x - bounds.width / 2 , halfscreen.y + 120 +28+ -bounds.height/2);
			window.draw(playtext);

			if (-190 / 2 + halfscreen.x <mousePos.x&&mousePos.x< -190 / 2 + halfscreen.x+ 190  &&
				halfscreen.y + 120 <mousePos.y&&mousePos.y< halfscreen.y + 120 + 80) {

				sf::RectangleShape ovrRect(sf::Vector2f(190, 80));
				ovrRect.setPosition(sf::Vector2f(-190 / 2 + halfscreen.x, halfscreen.y + 120));
				ovrRect.setFillColor(sf::Color(240, 240, 240,50));
				window.draw(ovrRect);
				if (menuMouseDown) {
					gameState = 1;
					bullets.clear();
					players.clear();
					ais.clear();

					switch (menuSelected) {
					case 0:
						mainPlayer = *new player(&mastertype);
						break;
					case 1:
						mainPlayer = *new player(&twintype);
						break;
					case 2:
						mainPlayer = *new player(&snipetype);
						break;
					case 3:
						mainPlayer = *new player(&shotguntype);
						break;
					}
					players.push_back(&mainPlayer);

					for (int i = 0; i < 50; i++) {
						player* newai = NULL;
						switch (rd() % 4) {
						case 0:
							newai = new player(&defauttype);

							break;
						case 1:
							newai = new player(&twintype);

							break;
						case 2:
							newai = new player(&snipetype);

							break;
						case 3:
							newai = new player(&shotguntype);

							break;
						}

						(*newai).x = rd() % (int)(rightbound - leftbound) + leftbound;
						(*newai).y = rd() % (int)(bottombound - topbound) + topbound;

						players.push_back(newai);
						ai* aiai = new ai(newai);
						ais.push_back(aiai);

					}
				}
			}


			window.display();

		}else if(gameState==1) {
			auto framestart = std::chrono::system_clock::now();
			while (window.pollEvent(event)) {

				if (event.type == sf::Event::Closed) {

					window.close();

				}
				if (event.type == sf::Event::KeyPressed) {
					if (event.key.code == sf::Keyboard::W) {
						mainPlayer.keyboard[0] = true;
					}
					if (event.key.code == sf::Keyboard::A) {
						mainPlayer.keyboard[1] = true;
					}
					if (event.key.code == sf::Keyboard::S) {
						mainPlayer.keyboard[2] = true;
					}
					if (event.key.code == sf::Keyboard::D) {
						mainPlayer.keyboard[3] = true;
					}
				}
				if (event.type == sf::Event::KeyReleased) {
					if (event.key.code == sf::Keyboard::W) {

						mainPlayer.keyboard[0] = false;
					}
					if (event.key.code == sf::Keyboard::A) {
						mainPlayer.keyboard[1] = false;
					}
					if (event.key.code == sf::Keyboard::S) {
						mainPlayer.keyboard[2] = false;
					}
					if (event.key.code == sf::Keyboard::D) {
						mainPlayer.keyboard[3] = false;
					}
				}
				if (event.type == sf::Event::MouseButtonPressed) {
					if (event.mouseButton.button == sf::Mouse::Left) {
						mainPlayer.mousedown = true;
					}
				}
				if (event.type == sf::Event::MouseButtonReleased) {
					if (event.mouseButton.button == sf::Mouse::Left) {
						mainPlayer.mousedown = false;
					}
				}
			}
			sf::Vector2f campos = camera.getCenter();

			sf::Vector2f newcenter = (sf::Vector2f(mainPlayer.x*.2 + campos.x * .8, mainPlayer.y*.2 + campos.y * .8));
			camera.setCenter(newcenter);
			campos = newcenter;
			window.setView(camera);

			sf::Vector2i mousePos = sf::Mouse::getPosition(window);
			mainPlayer.aimAngle = atan2(mousePos.y - mainPlayer.y + campos.y - halfscreen.y, mousePos.x - mainPlayer.x + campos.x - halfscreen.x);

			window.clear(sf::Color(240, 240, 240));

			sf::RectangleShape leftboundrect(sf::Vector2f(20, bottombound - topbound + 40));
			leftboundrect.setPosition(sf::Vector2f(leftbound - 20, topbound - 20));
			leftboundrect.setFillColor(sf::Color(150, 150, 150));
			window.draw(leftboundrect);

			sf::RectangleShape rightboundrect(sf::Vector2f(20, bottombound - topbound + 40));
			rightboundrect.setPosition(sf::Vector2f(rightbound, topbound - 20));
			rightboundrect.setFillColor(sf::Color(150, 150, 150));
			window.draw(rightboundrect);

			sf::RectangleShape topboundrect(sf::Vector2f(rightbound - leftbound, 20));
			topboundrect.setPosition(sf::Vector2f(leftbound, topbound - 20));
			topboundrect.setFillColor(sf::Color(150, 150, 150));
			window.draw(topboundrect);

			sf::RectangleShape bottomboundrect(sf::Vector2f(rightbound - leftbound, 20));
			bottomboundrect.setPosition(sf::Vector2f(leftbound, bottombound));
			bottomboundrect.setFillColor(sf::Color(150, 150, 150));
			window.draw(bottomboundrect);
			//bullet code
			for (int i = bullets.size() - 1; i >= 0; i--) {

				bullet* bulletpointer = bullets[i];
				bullet thisbullets = *bulletpointer;
				if ((campos.x - screensize.x / 2 - 50 < thisbullets.x) && (campos.y - screensize.y / 2 - 50 < thisbullets.y) && (campos.x + screensize.x / 2 + 50 > thisbullets.x) && (campos.y + screensize.y / 2 + 50 > thisbullets.y)) {

					(*bulletpointer).draw(window);
				}
				(*bulletpointer).tick();
				if ((*bulletpointer).health <= 0 || (*bulletpointer).x > rightbound || (*bulletpointer).x < leftbound || (*bulletpointer).y <topbound || (*bulletpointer).y> bottombound)bullets.erase(bullets.begin() + i);

			}
			std::vector<player> playersToAdd;
			//draw and tick players
			for (int i = players.size()-1; i>=0;i--) {
				player* playerpointer = players[i];
				player thisplayer = *playerpointer;
				if ((campos.x - screensize.x / 2 - 50 < thisplayer.x) && (campos.y - screensize.y / 2 - 50 < thisplayer.y) && (campos.x + screensize.x / 2 + 50 > thisplayer.x) && (campos.y + screensize.y / 2 + 50 > thisplayer.y)) {
					(*playerpointer).draw(window);
				}

				(*playerpointer).tick();
				if (thisplayer.x > rightbound - 30) {
					(*playerpointer).x = rightbound - 30;
					(*playerpointer).xv = 0;
				}
				if (thisplayer.x < leftbound + 30) {
					(*playerpointer).x = leftbound + 30;
					(*playerpointer).xv = 0;
				}
				if (thisplayer.y < topbound + 30) {
					(*playerpointer).y = topbound + 30;
					(*playerpointer).yv = 0;
				}
				if (thisplayer.y > bottombound - 30) {
					(*playerpointer).y = bottombound - 30;
					(*playerpointer).yv = 0;
				}
				//bullet shoot
				if (thisplayer.mousedown && (ticks - thisplayer.lastShoot) > thisplayer.thistype->reloadTime) {


					(*playerpointer).setShootTime();
					std::vector<bullet*> newBullets = ((*thisplayer.thistype).shootFunc)(playerpointer);
					std::cout << newBullets.size() << '\n';
					bullets.insert(bullets.end(), newBullets.begin(), newBullets.end());
					(*playerpointer).xv += cos(thisplayer.aimAngle) * -3;
					(*playerpointer).yv += sin(thisplayer.aimAngle) * -3;
					if (thisplayer.thistype==&mastertype) {
						player* newai = NULL;
						newai = new player(&slavetype);

						newai->owner = playerpointer;
						(*newai).x = thisplayer.x+cos(thisplayer.aimAngle)*45;
						(*newai).y = thisplayer.y+sin(thisplayer.aimAngle) * 45;
						(*newai).xv =  cos(thisplayer.aimAngle) * 15;
						(*newai).yv =  sin(thisplayer.aimAngle) * 15;
						newai->health = 40;

						players.push_back(newai);
						ai* aiai = new ai(newai);
						aiai->owner = playerpointer;

						ais.push_back(aiai);
					}
				}
				/*
				if (playersToAdd.size()>0) {
					players.push_back(&playersToAdd[0]);

					//std::cout << playersToAdd[0]<<"\n";
				}*/
				//players.insert(players.end(), playersToAdd.begin(), playersToAdd.end());
				//health
				for (int i = bullets.size() - 1; i >= 0; i--) {
					bullet* bulletpointer = bullets[i];
					bullet thisBullet = *bulletpointer;
					if (dist(thisBullet.x, thisBullet.y, thisplayer.x, thisplayer.y) < (31 + thisBullet.size) && thisBullet.owner != playerpointer&&thisBullet.owner!= playerpointer->owner && (*playerpointer).health > 0) {
						(*playerpointer).health -= thisBullet.dmg;
						(*playerpointer).xv += thisBullet.xv *thisBullet.size / 33;
						(*playerpointer).yv += thisBullet.yv  *thisBullet.size / 33;
						if ((*playerpointer).health <= 0 && (thisBullet.owner) == (&mainPlayer))kills++;

						bullets.erase(bullets.begin() + i);

					}

				}

			}
			//player collision
			for (player* playerpointer : players) {
				player thisplayer = *playerpointer;

				for (player* otherplayerpointer : players) {
					player otherplayer = *otherplayerpointer;
					float distTo = dist(thisplayer.x, thisplayer.y, otherplayer.x, otherplayer.y);
					if (distTo < 62 && distTo>0) {
						(*playerpointer).xv += (thisplayer.x - otherplayer.x) / distTo;
						(*playerpointer).yv += (thisplayer.y - otherplayer.y) / distTo;
					}

				}

			}
			//AI
			//test.step(&bullets, &players);
			for (ai* aipointer : ais) {
				(*aipointer).step(&bullets, &players, leftbound, rightbound, topbound, bottombound);
			}
			if (mainPlayer.dead) {
				gameState = 0;
			}

			for (int i = players.size() - 1; i >= 0; i--) {
				player* playerpointer = players[i];

				if ((*playerpointer).health <= 0) {
					(*playerpointer).dead = true;
					players.erase(players.begin() + i);
				}


			}
			int playercount = 0;
			for (player* playerpointer:players) {
				if (playerpointer->owner == NULL)playercount++;
			}
			if (playercount <40) {
				player* newai = NULL;
				switch (rd() % 4) {
				case 0:
					newai = new player(&defauttype);

					break;
				case 1:
					newai = new player(&twintype);

					break;
				case 2:
					newai = new player(&snipetype);

					break;
				case 3:
					newai = new player(&shotguntype);

					break;
				}

				(*newai).x = rd() % (int)(rightbound - leftbound) + leftbound;
				(*newai).y = rd() % (int)(bottombound - topbound) + topbound;

				players.push_back(newai);
				ai* aiai = new ai(newai);
				ais.push_back(aiai);

			}

			sf::RectangleShape minimapOutline(sf::Vector2f(150, 150));
			minimapOutline.setPosition(campos.x + halfscreen.x - 10 - 150, campos.y - halfscreen.y + 10);
			minimapOutline.setOutlineColor(sf::Color(175, 175, 175, 150));
			minimapOutline.setOutlineThickness(3);
			minimapOutline.setFillColor(sf::Color(240, 240, 240, 150));
			window.draw(minimapOutline);

			for (player* otherplayerpointer : players) {
				sf::CircleShape circleI;
				circleI.setRadius(2);
				circleI.setPosition(((*otherplayerpointer).x - leftbound) / (rightbound - leftbound) * 150 + campos.x + halfscreen.x - 150 - 10 - 1, ((*otherplayerpointer).y - topbound) / (bottombound - topbound) * 150 + campos.y - halfscreen.y + 10 - 1);
				circleI.setFillColor(sf::Color(175, 175, 175, 150));
				window.draw(circleI);
			}
			sf::CircleShape circleI;
			circleI.setRadius(3);
			circleI.setPosition((mainPlayer.x - leftbound) / (rightbound - leftbound) * 150 + campos.x + halfscreen.x - 150 - 10 - 1.5, ((mainPlayer).y - topbound) / (bottombound - topbound) * 150 + campos.y - halfscreen.y + 10 - 1.5);
			circleI.setFillColor(sf::Color(200, 125, 125, 255));
			window.draw(circleI);

			sf::Text PlayersText;
			PlayersText.setFont(arial);
			PlayersText.setString(std::string("Players ") + std::to_string(playercount));
			PlayersText.setCharacterSize(15);
			PlayersText.setFillColor(sf::Color(175, 175, 175, 255));
			PlayersText.setPosition(campos.x + halfscreen.x - 150 - 10 - 1, campos.y - halfscreen.y + 150 + 16);
			window.draw(PlayersText);

			sf::Text killsText;
			killsText.setFont(arial);
			killsText.setString(std::string("Kills: ") + std::to_string(kills));
			killsText.setCharacterSize(15);
			killsText.setFillColor(sf::Color(175, 175, 175, 255));
			killsText.setPosition(campos.x + halfscreen.x - 150 - 10 - 1, campos.y - halfscreen.y + 150 + 16 + 20);
			window.draw(killsText);

			sf::Text FPSText;
			FPSText.setFont(arial);
			auto frameend = std::chrono::system_clock::now();

			FPSText.setString(std::string("FPS ") + std::to_string(1000 / std::max(30, (int)std::chrono::duration_cast<std::chrono::milliseconds>(frameend - framestart).count())));
			FPSText.setCharacterSize(15);
			FPSText.setFillColor(sf::Color::Black);
			FPSText.setPosition(campos.x - halfscreen.x, campos.y - halfscreen.y);
			window.draw(FPSText);


			window.display();
			std::this_thread::sleep_for(std::chrono::milliseconds(30 - std::chrono::duration_cast<std::chrono::milliseconds>(frameend - framestart).count()));
			ticks++;
		}
	}


}

