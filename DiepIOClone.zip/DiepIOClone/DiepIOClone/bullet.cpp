#include "pch.h"
#include <SFML/Graphics.hpp>

#include "bullet.h"

bullet::bullet(double xx, double yy, double xxv, double yyv, double sze,double dm, player* onr) {
	owner = onr;
	xv = xxv;
	yv = yyv;
	x = xx;
	y = yy;
	dmg = dm;
	size = sze;
	health = 20;
}
void bullet::draw(sf::RenderWindow &window) {
	float opp = 255;
	if (health<1.5) {
		opp = health / 1.5 * 255;
	}
	sf::CircleShape circle;
	circle.setRadius(size);
	circle.setPosition(x - size, y - size);
	circle.setFillColor(sf::Color(175, 175, 175,opp));
	window.draw(circle);

	sf::CircleShape circleI;
	circleI.setRadius(size-4);
	circleI.setPosition(x - size+4,y - size +4);
	circleI.setFillColor(sf::Color(210, 210, 210,opp));
	window.draw(circleI);
}
void bullet::tick() {
	x += xv;
	y += yv;
	health -= .3;
}