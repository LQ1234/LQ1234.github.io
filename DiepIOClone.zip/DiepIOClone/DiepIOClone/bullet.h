#pragma once
#include <string>
#include <iostream>
#include <SFML/Graphics.hpp>
#include "player.h"

class bullet{
public:
	double x,y,xv,yv,health,size,dmg;
	player* owner;
	bullet(double xx, double yy, double xxv, double yyv,  double sze,double dm, player* onr);
	void draw(sf::RenderWindow&);
	void tick();

};