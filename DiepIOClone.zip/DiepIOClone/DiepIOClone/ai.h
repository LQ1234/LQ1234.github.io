#pragma once

#include <vector>
#include "bullet.h"
#include "player.h"
#include <random>


class ai {
public:
	ai(player* tPlayer);
	player* thisPlayer;
	player* target;
	player* owner;

	float strafeAngle;
	bool strafeDirection;
	std::random_device rd;
	double wanderX;
	double wanderY;
	void step(std::vector<bullet*>* bullets, std::vector<player*>* players,double leftbound, double rightbound, double topbound, double bottombound);
};