#include "pch.h"
#include <SFML/Graphics.hpp>

#include "type.h"

type::type(sf::Sprite* spri, std::vector<bullet*> (*shootF)(player* thisPlayer),int rlt) {
	thissprite = spri;
	shootFunc = shootF;
	reloadTime = rlt;
}