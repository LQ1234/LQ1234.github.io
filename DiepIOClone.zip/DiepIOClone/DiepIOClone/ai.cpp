#include "pch.h"
#include "bullet.h"
#include "player.h"
#include "ai.h"

ai::ai(player * tPlayer)
{
	thisPlayer = tPlayer;
	wanderX = (*tPlayer).x;
	wanderY = (*tPlayer).y;
	owner = NULL;
}
double ddist(double x1, double y1, double x2, double y2) {
	return(sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2)));
}
void ai::step(std::vector<bullet*>* bullets, std::vector<player*>* players, double leftbound, double rightbound, double topbound, double bottombound)
{

	if (target == NULL) {

		double closestDistance = 800;
		player* closest = NULL;
		for (player* playerpointer : *players) {
			double thisDistance = ddist((*thisPlayer).x, (*thisPlayer).y, (*playerpointer).x, (*playerpointer).y);
			if (closestDistance > thisDistance&&thisDistance > 0&&(playerpointer!= owner) &&((playerpointer->owner ==NULL) ||(playerpointer->owner != owner))) {
				closest = playerpointer;
				closestDistance = thisDistance;
			}
		}
		target = closest;
		(*thisPlayer).mousedown = false;
		if (target!=NULL){
			strafeAngle = atan2( (*thisPlayer).y- (*target).y, (*thisPlayer).x-(*target).x );
			strafeDirection = true;
		}
		else {
			double speed = 2;

			if (ddist((*thisPlayer).x, (*thisPlayer).y, wanderX, wanderY) < 20) {
				if (owner == NULL) {
					do {
						wanderX = ((*thisPlayer).x + ((rd() % 3000)*1.0 - 1500));
						wanderY = ((*thisPlayer).y + ((rd() % 3000)*1.0 - 1500));
					} while (wanderX<leftbound || wanderX>rightbound || wanderY<topbound || wanderY>bottombound);
				}
				else {
					do {
						wanderX = ((*owner).x + ((rd() % 600)*1.0 - 300));
						wanderY = ((*owner).y + ((rd() % 600)*1.0 - 300));
					} while (wanderX<leftbound || wanderX>rightbound || wanderY<topbound || wanderY>bottombound);
				}
			}
			
			double  modedir = atan2(wanderY - (*thisPlayer).y, wanderX - (*thisPlayer).x);
			(*thisPlayer).aimAngle = .5*(*thisPlayer).aimAngle + .5*modedir;

			(*thisPlayer).xv += cos(modedir)*speed;
			(*thisPlayer).yv += sin(modedir)*speed;
		}
	}
	else {

		double speed = 2;
		if ((*thisPlayer).health > 25) {
			//strafeAngle = atan2((*thisPlayer).y - (*target).y, (*thisPlayer).x - (*target).x);
			if (rd() % 40 == 0)strafeDirection = !strafeDirection;
			if (strafeDirection) {
				strafeAngle += .07;
			}
			else {
				strafeAngle -= .07;

			}

			double targetX = cos(strafeAngle) * 400 + (*target).x, targetY = sin(strafeAngle) * 400 + (*target).y;
			double  modedir = atan2(targetY - (*thisPlayer).y, targetX - (*thisPlayer).x);

			(*thisPlayer).xv += cos(modedir)*speed;
			(*thisPlayer).yv += sin(modedir)*speed;
		}
		else {
			double modedir = atan2((*target).y - (*thisPlayer).y , (*target).x - (*thisPlayer).x);
			(*thisPlayer).xv -= cos(modedir)*speed;
			(*thisPlayer).yv -= sin(modedir)*speed;
		}
		double distTo = ddist((*thisPlayer).x, (*thisPlayer).y, (*target).x, (*target).y);

		double toaim= atan2((*target).y-(*thisPlayer).y+ (*target).xv*distTo/15/2, (*target).x - (*thisPlayer).x + (*target).xv*distTo/15/2);
		(*thisPlayer).aimAngle = .5*(*thisPlayer).aimAngle + .5*toaim;
		(*thisPlayer).mousedown = true;
		
		if ((distTo>1250)||(distTo>900&& (*target).health>25)|| (*target).dead||(owner!=NULL&& ddist((*thisPlayer).x, (*thisPlayer).y, (*owner).x, (*owner).y) > 700)) {
			target = NULL;
			wanderX = (*thisPlayer).x;
			wanderY = (*thisPlayer).y;
		}
	}

}