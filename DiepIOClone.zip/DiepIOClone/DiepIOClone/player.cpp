
#include "pch.h"
#include <vector>
#include "bullet.h"
#include "global.h"

#include <chrono>

#include "player.h"
#include <SFML/Graphics.hpp>

const double PI = 3.141592653589793;

void player::setShootTime() {

	lastShoot = ticks;

}

player::player(type* typ) {
	owner = NULL;
	health = 100;
	thistype = typ;
	xv = 0;
	yv = 0;
	x = 250;
	y = 250;
	keyboard[0]=false;
	keyboard[1] = false;
	keyboard[2] = false;
	keyboard[3] = false;
	mousedown = false;
	aimAngle = 0;
	setShootTime();
	dead = false;
}

void player::draw(sf::RenderWindow &window) {

	sf::Sprite sprite;
	sprite = *(*thistype).thissprite;
	//std::cout <<(* (*sprite).getTexture()).isSmooth();
	(sprite).setRotation(aimAngle / PI * 180.f);
	(sprite).setPosition(sf::Vector2f(x,y)); // absolute position

	if (owner==NULL) {
		sf::RectangleShape healthBar(sf::Vector2f(70, 10));
		healthBar.setPosition(x - 35, y + 40);
		healthBar.setFillColor(sf::Color(175, 175, 175));
		window.draw(healthBar);

		sf::RectangleShape healthBarI(sf::Vector2f(65 * health / 100, 5));
		healthBarI.setPosition(x - 35 + 2.5, y + 40 + 2.5);
		healthBarI.setFillColor(sf::Color(210, 60, 60));
		window.draw(healthBarI);
	}
	else {
		sf::RectangleShape healthBar(sf::Vector2f(50, 10));
		healthBar.setPosition(x - 25, y + 40);
		healthBar.setFillColor(sf::Color(175, 175, 175));
		window.draw(healthBar);

		sf::RectangleShape healthBarI(sf::Vector2f(45 * health / 40, 5));
		healthBarI.setPosition(x - 25 + 2.5, y + 40 + 2.5);
		healthBarI.setFillColor(sf::Color(210, 60, 60));
		window.draw(healthBarI);
	}
	window.draw(sprite);
	/*

	*/
}
void player::tick() {
	if (owner == NULL) {

		if (health < 99)health += .3;
	}
	else {
		if (health < 39)health += .3;

	}
	x += xv;
	y += yv;
	yv *= .8;
	xv *= .8;
	double speed = 2;
	if (keyboard[0] != keyboard[2] && keyboard[1] != keyboard[3])speed = sqrt(speed);
	if (keyboard[0])yv-= speed;
	if (keyboard[2])yv+= speed;
	if (keyboard[3])xv+= speed;
	if (keyboard[1])xv-= speed;

}