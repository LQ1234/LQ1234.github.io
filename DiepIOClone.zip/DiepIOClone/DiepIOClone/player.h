#pragma once
#include <string>
#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
#include "bullet.h"


#include "type.h"



#include <chrono>

class player {
public:
	double x, y, xv, yv,health;
	bool keyboard[4];
	bool mousedown;
	bool dead;
	player* owner;
	double aimAngle;
	long lastShoot;
	player(type* typ);

	void setShootTime();
	void draw(sf::RenderWindow&);
	void tick( );
	type* thistype;
};